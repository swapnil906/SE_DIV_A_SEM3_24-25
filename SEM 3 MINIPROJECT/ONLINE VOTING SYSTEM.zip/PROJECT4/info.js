// Initialize Firebase
const firebaseConfig = {
    apiKey: "AIzaSyBWM3SAgY2KsQOEbZV-G2cRyWeUzvPM6IM",
    authDomain: "onlinevotingsystem-3c54b.firebaseapp.com",
    projectId: "onlinevotingsystem-3c54b",
    storageBucket: "onlinevotingsystem-3c54b.appspot.com",
    messagingSenderId: "424075405837",
    appId: "1:424075405837:web:d6470ec5d2759af2914344"
  };
  firebase.initializeApp(firebaseConfig);
  const db = firebase.firestore();
  
// Get the candidates container
const candidatesContainer = document.getElementById('candidates');

// Fetch data from Firestore
db.collection('Election for College President').get()
  .then(snapshot => {
    snapshot.forEach(doc => {
      // Create a candidate element
      const candidateDiv = document.createElement('div');
      candidateDiv.classList.add('candidate');

      // Add candidate details
      candidateDiv.innerHTML = `
        <h2>${doc.data().Name}</h2>
        <img src="${doc.data().PhotoUrl}" alt="${doc.data().Name}">
        <p>${doc.data().Bio}</p>
        <p>Votes: ${doc.data().votes}</p>
      `;

      // Append to the container
      candidatesContainer.appendChild(candidateDiv);
    });
  })
  .catch(error => {
    console.error("Error getting documents: ", error);
  });