import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js';
import { collection, doc, getDoc, getDocs, getFirestore, increment, updateDoc } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js';


// Your Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBWM3SAgY2KsQOEbZV-G2cRyWeUzvPM6IM",
    authDomain: "onlinevotingsystem-3c54b.firebaseapp.com",
    projectId: "onlinevotingsystem-3c54b",
    storageBucket: "onlinevotingsystem-3c54b.appspot.com",
    messagingSenderId: "424075405837",
    appId: "1:424075405837:web:d6470ec5d2759af2914344"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth();


// Ensure Firebase initialization is done correctly and db is available
// const db = getFirestore(app); // Assuming db is initialized properly



// Function to handle voting
async function handleVote(candidateId) {
    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
        alert('Please sign in to vote.');
        console.log('User is not signed in.');
        return;
    }

    console.log('User is signed in:', user.uid);

    const userDocRef = doc(db, 'users', user.uid);
    const candidateDocRef = doc(db, 'Election for College President', candidateId);

    // Check if the user has already voted
    const userDoc = await getDoc(userDocRef);
    if (userDoc.exists()) {
        const voted = userDoc.data().voted;
        console.log('User voting status:', voted);

        if (voted) {
            alert('You have already voted!');
            console.log('User already voted.');
            return;
        } else {
            // Update the user's voted status to true
            console.log('Updating user voted status to true...');
            await updateDoc(userDocRef, { voted: true });
        }
    } else {
        console.log('User document not found.');
        return;
    }

    // Increment the candidate's vote count
    console.log('Incrementing vote count for candidate:', candidateId);
    await updateDoc(candidateDocRef, {
        Votes: increment(1) // Firebase Firestore increment to increase vote count by 1
    });

    alert('Your vote has been counted!');
    console.log('Vote successfully counted.');
}

window.handleVote = handleVote;

// Adding event listeners to the Vote buttons
async function fetchElections() {
    const electionsContainer = document.getElementById('electionsContainer');
    electionsContainer.innerHTML = ''; // Clear existing content

    // Fetch the candidates from Firestore under the "Election for College President" collection
    const candidatesCollection = collection(db, 'Election for College President');
    const querySnapshot = await getDocs(candidatesCollection);

    // Check if there are any candidates
    if (querySnapshot.empty) {
        electionsContainer.innerHTML = '<p>No elections found.</p>';
        return;
    }

    // Create a card for the election
    const electionCard = document.createElement('div');
    electionCard.className = 'election-card';

    // Create a header for the election that acts as a link
    const electionHeader = document.createElement('h3');
    electionHeader.innerHTML = `<a href="#" style="text-decoration: none; color: #d9534f;">Election for College President</a>`;
    
    // Create a table for candidates
    const candidatesTable = document.createElement('table');
    candidatesTable.style.width = '100%';
    candidatesTable.style.borderCollapse = 'collapse';
    candidatesTable.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
    candidatesTable.style.marginTop = '20px';
    candidatesTable.style.display = 'none'; // Initially hide the table
    candidatesTable.innerHTML = `
        <tr style="background-color: #f2f2f2;">
            <th style="border: 5px solid #ccc; padding: 10px;">Candidate Image</th>
            <th style="border: 5px solid #ccc; padding: 10px;">Candidate Name</th>
            <th style="border: 5px solid #ccc; padding: 10px;">Vote</th>
        </tr>
    `;

    // Add click event to toggle the table visibility
    electionHeader.querySelector('a').addEventListener('click', (event) => {
        event.preventDefault(); // Prevent default link behavior
        candidatesTable.style.display = candidatesTable.style.display === 'none' ? 'table' : 'none';
    });

    // Loop through candidates and display their info
    querySnapshot.forEach((doc) => {
        const candidateData = doc.data(); // Get candidate data
        const candidateName = candidateData.Name;
        const candidatePhotoUrl = candidateData.Photourl;
        const candidateId = doc.id; // Get the document ID for the candidate

        // Create a row for the candidate
        const candidateRow = document.createElement('tr');
        candidateRow.innerHTML = `
            <td style="border: 1px solid #ccc; padding: 10px; text-align: center;">
                <img src="${candidatePhotoUrl}" alt="${candidateName}" style="width: 250px; height: 250px; border-radius: 8px;">
            </td>
            <td style="border: 1px solid #ccc; padding: 10px; text-align: center; font-size: 18px;">
                ${candidateName}
            </td>
            <td style="border: 1px solid #ccc; padding: 10px; text-align: center;">
                <button 
                    style="padding: 12px 24px; font-size: 18px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s;"
                    onclick="handleVote('${candidateId}')">
                    Vote
                </button>
            </td>
        `;
        candidatesTable.appendChild(candidateRow);
    });

    // Append the election header and candidates table to the election card
    electionCard.appendChild(electionHeader);
    electionCard.appendChild(candidatesTable);
    electionsContainer.appendChild(electionCard);
}

// Call the function to fetch elections when the page loads
window.onload = fetchElections;
