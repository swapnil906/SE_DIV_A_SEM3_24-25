
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { collection, getDocs, getFirestore } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-firestore.js";

  const firebaseConfig = {
    apiKey: "AIzaSyBWM3SAgY2KsQOEbZV-G2cRyWeUzvPM6IM",
    authDomain: "onlinevotingsystem-3c54b.firebaseapp.com",
    projectId: "onlinevotingsystem-3c54b",
    storageBucket: "onlinevotingsystem-3c54b.appspot.com",
    messagingSenderId: "424075405837",
    appId: "1:424075405837:web:d6470ec5d2759af2914344"
  };

  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);

  async function displayCandidates() {
    const candidatesCollection = collection(db, "Election for College President");
    const candidateSnapshot = await getDocs(candidatesCollection);

    let output = "";
    candidateSnapshot.forEach((doc) => {
      const candidate = doc.data();
      output += `
        <div>
          <h2>${candidate.Name}</h2>
          <p>Bio: ${candidate.Bio}</p>
          <p>Election: ${candidate.Election}</p>
          <img src="${candidate.Photourl}" alt="${candidate.Name}" style="width: 300px; height: 300px;">
        </div>
      `;
    });

    document.getElementById("candidateInfo").innerHTML = output;
  }

  displayCandidates();

